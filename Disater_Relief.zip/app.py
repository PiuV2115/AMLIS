import pickle

import firebase_admin
from firebase_admin import credentials, firestore
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# =========================
# LOAD ALL 6 MODELS
# =========================

with open("cyclone_model.pkl", "rb") as f:
    cyclone_model, cyclone_scaler = pickle.load(f)

with open("flood_model.pkl", "rb") as f:
    flood_model, flood_scaler = pickle.load(f)

with open("earthquake_model.pkl", "rb") as f:
    earthquake_model, earthquake_scaler = pickle.load(f)

with open("wildfire_model.pkl", "rb") as f:
    wildfire_model, wildfire_scaler = pickle.load(f)

with open("tsunami_model.pkl", "rb") as f:
    tsunami_model, tsunami_scaler = pickle.load(f)

with open("landslide_model.pkl", "rb") as f:
    landslide_model, landslide_scaler = pickle.load(f)

# =========================
# FIREBASE
# =========================

cred = credentials.Certificate("firebase_key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()


# =========================
# HELPERS
# =========================

def clamp(val, lo=0, hi=100):
    return min(max(float(val), lo), hi)


def priority_to_risk(pred):
    """Convert model priority output (1-5) to risk percentage (0-100)."""
    return clamp((pred / 5) * 100)


def risk_level(pct):
    if pct >= 75:
        return "CRITICAL"
    if pct >= 55:
        return "HIGH"
    if pct >= 35:
        return "MODERATE"
    return "LOW"


def estimated_casualties(risk_pct, population):
    base = (risk_pct / 100) ** 2 * population * 0.002
    lo = int(base * 0.5)
    hi = int(base * 2.0)
    if hi < 5:
        return "Minimal (<5)"
    return f"{lo:,}-{hi:,}"


def economic_loss(risk_pct, affected_km2):
    loss = risk_pct * affected_km2 * 50_000
    if loss < 1_000_000:
        return f"${loss / 1000:.0f}K"
    if loss < 1_000_000_000:
        return f"${loss / 1_000_000:.1f}M"
    return f"${loss / 1_000_000_000:.2f}B"


def key_factors(disaster, params):
    factors = {
        "cyclone":    [f"Wind {params.get('wind_speed','?')} km/h",
                       f"Storm surge {params.get('storm_surge','?')} m",
                       f"Pressure {params.get('pressure','?')} hPa"],
        "flood":      [f"Rainfall {params.get('rainfall','?')} mm/hr",
                       f"River +{params.get('river_level','?')} m",
                       f"Soil sat. {params.get('soil_saturation','?')}%"],
        "earthquake": [f"Mw {params.get('magnitude','?')}",
                       f"Depth {params.get('depth','?')} km",
                       f"Liquefaction {params.get('soil_liquefaction','?')}%"],
        "wildfire":   [f"Humidity {params.get('humidity','?')}%",
                       f"Wind {params.get('wind_speed','?')} km/h",
                       f"Fuel moisture {params.get('fuel_moisture','?')}%"],
        "tsunami":    [f"Wave {params.get('wave_height','?')} m",
                       f"Lead time {params.get('warning_lead_time','?')} min",
                       f"Mw {params.get('magnitude','?')}"],
        "landslide":  [f"Slope {params.get('slope_angle','?')} deg",
                       f"Rainfall {params.get('rainfall','?')} mm",
                       f"Saturation {params.get('soil_saturation','?')}%"],
    }
    return factors.get(disaster, ["Multiple risk factors detected"])


def immediate_actions(level):
    actions = {
        "CRITICAL": [
            "Initiate immediate mass evacuation of all at-risk zones",
            "Deploy emergency response teams and field hospitals",
            "Activate national disaster management authority",
            "Issue highest-level public alert across all channels",
        ],
        "HIGH": [
            "Order precautionary evacuation of high-risk areas",
            "Pre-position emergency supplies and rescue equipment",
            "Put hospitals and emergency services on standby",
            "Broadcast warnings through all available media",
        ],
        "MODERATE": [
            "Issue public advisories and safety guidelines",
            "Prepare evacuation routes and shelters",
            "Monitor conditions with increased frequency",
            "Coordinate with local disaster management teams",
        ],
        "LOW": [
            "Continue standard monitoring protocols",
            "Review and update emergency preparedness plans",
            "Ensure early-warning systems are operational",
            "Conduct public awareness outreach",
        ],
    }
    return actions.get(level, actions["MODERATE"])


def summary(disaster, level, risk_pct):
    templates = {
        "cyclone":    f"A {level.lower()} risk cyclone scenario with {risk_pct:.0f}% overall threat index. Coastal communities require immediate preparedness measures.",
        "flood":      f"Flood risk assessment indicates a {level.lower()} threat ({risk_pct:.0f}%). River basin and urban drainage systems are under significant stress.",
        "earthquake": f"Seismic analysis shows a {level.lower()} risk ({risk_pct:.0f}%) with structural damage likely in high-density zones.",
        "wildfire":   f"Wildfire conditions are {level.lower()} risk ({risk_pct:.0f}%). Dry fuel and wind alignment create dangerous fire-spread potential.",
        "tsunami":    f"Tsunami propagation model indicates {level.lower()} threat ({risk_pct:.0f}%). Coastal inundation zones should be prioritised for evacuation.",
        "landslide":  f"Slope stability analysis yields a {level.lower()} risk score ({risk_pct:.0f}%). Saturated terrain and steep gradients are primary drivers.",
    }
    return templates.get(disaster, f"{level} risk detected ({risk_pct:.0f}%). Initiate appropriate response protocols.")


def build_response(disaster, risk_pct, params, population, affected_km2):
    level = risk_level(risk_pct)
    return {
        "risk":                  round(risk_pct, 2),
        "level":                 level,
        "estimated_casualties":  estimated_casualties(risk_pct, population),
        "affected_area_km2":     round(affected_km2),
        "economic_loss_usd":     economic_loss(risk_pct, affected_km2),
        "radar_scores": {
            "severity":              clamp(risk_pct * 1.1),
            "population_impact":     clamp(risk_pct * (population / 500)),
            "infrastructure_threat": clamp(risk_pct * 0.9),
            "warning_time":          clamp(100 - risk_pct * 0.7),
            "economic_impact":       clamp(risk_pct * 0.85),
        },
        "key_factors":       key_factors(disaster, params),
        "immediate_actions": immediate_actions(level),
        "summary":           summary(disaster, level, risk_pct),
    }


# =========================
# PREDICT ENDPOINT
# =========================

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data     = request.get_json()
        disaster = data.get("type", "").lower()

        # ── CYCLONE ──────────────────────────────────────────────────────────
        if disaster == "cyclone":
            params = {
                "wind_speed":         float(data["wind_speed"]),
                "pressure":           float(data["pressure"]),
                "storm_surge":        float(data["storm_surge"]),
                "cyclone_diameter":   float(data["cyclone_diameter"]),
                "landfall_angle":     float(data["landfall_angle"]),
                "coastal_population": float(data["coastal_population"]),
            }
            severity     = params["wind_speed"]
            people       = params["coastal_population"]
            population   = people
            affected_km2 = params["cyclone_diameter"] ** 2 * 0.03
            X            = cyclone_scaler.transform([[severity, people]])
            pred         = cyclone_model.predict(X)[0]

        # ── FLOOD ─────────────────────────────────────────────────────────────
        elif disaster == "flood":
            params = {
                "rainfall":          float(data["rainfall"]),
                "duration":          float(data["duration"]),
                "river_level":       float(data["river_level"]),
                "soil_saturation":   float(data["soil_saturation"]),
                "urban_cover":       float(data["urban_cover"]),
                "drainage_capacity": float(data["drainage_capacity"]),
            }
            severity     = params["rainfall"]
            people       = params["river_level"] * 1000
            population   = 500
            affected_km2 = params["river_level"] * params["rainfall"] * 0.5
            X            = flood_scaler.transform([[severity, people]])
            pred         = flood_model.predict(X)[0]

        # ── EARTHQUAKE ───────────────────────────────────────────────────────
        elif disaster == "earthquake":
            params = {
                "magnitude":              float(data["magnitude"]),
                "depth":                  float(data["depth"]),
                "population_density":     float(data["population_density"]),
                "soil_liquefaction":      float(data["soil_liquefaction"]),
                "epicenter_distance":     float(data["epicenter_distance"]),
                "aftershock_probability": float(data["aftershock_probability"]),
            }
            severity     = params["magnitude"]
            people       = params["population_density"]
            population   = people
            affected_km2 = 3.14 * params["epicenter_distance"] ** 2
            X            = earthquake_scaler.transform([[severity, people]])
            pred         = earthquake_model.predict(X)[0]

        # ── WILDFIRE ─────────────────────────────────────────────────────────
        elif disaster == "wildfire":
            params = {
                "wind_speed":         float(data["wind_speed"]),
                "humidity":           float(data["humidity"]),
                "temperature":        float(data["temperature"]),
                "fuel_moisture":      float(data["fuel_moisture"]),
                "slope_angle":        float(data["slope_angle"]),
                "vegetation_density": float(data["vegetation_density"]),
            }
            # Severity proxy: high temp + low humidity = more dangerous
            severity     = params["temperature"] * (1 - params["humidity"] / 100)
            people       = params["vegetation_density"] * 100
            population   = 200
            affected_km2 = params["wind_speed"] * params["vegetation_density"] * 0.4
            X            = wildfire_scaler.transform([[severity, people]])
            pred         = wildfire_model.predict(X)[0]

        # ── TSUNAMI ──────────────────────────────────────────────────────────
        elif disaster == "tsunami":
            params = {
                "magnitude":          float(data["magnitude"]),
                "wave_height":        float(data["wave_height"]),
                "warning_lead_time":  float(data["warning_lead_time"]),
                "slope_angle":        float(data["slope_angle"]),
                "coastal_population": float(data["coastal_population"]),
                "source_distance":    float(data["source_distance"]),
            }
            severity     = params["wave_height"]
            people       = params["coastal_population"] * 1000
            population   = params["coastal_population"]
            affected_km2 = params["wave_height"] * params["coastal_population"] * 0.8
            X            = tsunami_scaler.transform([[severity, people]])
            pred         = tsunami_model.predict(X)[0]

        # ── LANDSLIDE ────────────────────────────────────────────────────────
        elif disaster == "landslide":
            params = {
                "rainfall":        float(data["rainfall"]),
                "slope_angle":     float(data["slope_angle"]),
                "soil_cohesion":   float(data["soil_cohesion"]),
                "soil_saturation": float(data["soil_saturation"]),
                "vegetation_loss": float(data["vegetation_loss"]),
                "seismic_trigger": float(data["seismic_trigger"]),
            }
            severity     = params["slope_angle"] * (params["soil_saturation"] / 100)
            people       = params["rainfall"] * 10
            population   = 150
            affected_km2 = params["slope_angle"] * params["rainfall"] * 0.1
            X            = landslide_scaler.transform([[severity, people]])
            pred         = landslide_model.predict(X)[0]

        else:
            return jsonify({"error": f"Unsupported disaster type: '{disaster}'"}), 400

        # ── Build and store response ──────────────────────────────────────────
        risk_pct = priority_to_risk(pred)
        response = build_response(disaster, risk_pct, params, population, affected_km2)

        db.collection("disasters").add({
            "type":  disaster,
            "risk":  response["risk"],
            "level": response["level"],
        })

        return jsonify(response)

    except KeyError as e:
        return jsonify({"error": f"Missing field: {e}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)