import pickle

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# =========================
# LOAD DATA
# =========================
df = pd.read_csv("disaster_data.csv")

print(f"Loaded {len(df)} rows across {df['disaster_type'].nunique()} disaster types")
print(df.groupby("disaster_type")["priority"].value_counts().unstack(fill_value=0))

# =========================
# FEATURE MAP
# Each disaster maps its 6 dashboard params → the 2 columns the scaler/model uses.
# "severity" and "people" are proxy columns computed from the raw features.
# =========================

FEATURE_MAP = {
    "cyclone": {
        "features": ["wind_speed", "coastal_population"],
        "comment":  "wind_speed as severity, coastal_population as people proxy",
    },
    "earthquake": {
        "features": ["magnitude", "population_density"],
        "comment":  "magnitude as severity, population_density as people proxy",
    },
    "flood": {
        "features": ["rainfall", "river_level"],
        "comment":  "rainfall as severity, river_level as people/impact proxy",
    },
    "wildfire": {
        "features": ["wind_speed", "humidity"],
        "comment":  "wind_speed as spread driver, humidity as inverse severity",
    },
    "tsunami": {
        "features": ["wave_height", "coastal_population"],
        "comment":  "wave_height as severity, coastal_population as people proxy",
    },
    "landslide": {
        "features": ["slope_angle", "soil_saturation"],
        "comment":  "slope as severity driver, soil_saturation as trigger proxy",
    },
}

# Best model per disaster (chosen for feature complexity + dataset size)
MODEL_MAP = {
    "cyclone":    RandomForestRegressor(n_estimators=100, random_state=42),
    "earthquake": LinearRegression(),
    "flood":      RandomForestRegressor(n_estimators=100, random_state=42),
    "wildfire":   RandomForestRegressor(n_estimators=100, random_state=42),
    "tsunami":    GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42),
    "landslide":  RandomForestRegressor(n_estimators=100, random_state=42),
}


# =========================
# PLOT HELPER
# =========================
def plot_results(y_test, preds, name):
    plt.figure()
    plt.scatter(y_test, preds, alpha=0.6)
    plt.xlabel("Actual Priority")
    plt.ylabel("Predicted Priority")
    plt.title(f"{name} — Actual vs Predicted")
    plt.tight_layout()
    plt.savefig(f"{name}_plot.png", dpi=100)
    plt.close()
    print(f"  Plot saved : {name}_plot.png")


# =========================
# TRAIN FUNCTION
# =========================
def train_model(data, features, model, name):
    if len(data) < 10:
        print(f"\nNot enough data for {name} ({len(data)} rows). Skipping.")
        return

    X = data[features].dropna()
    y = data.loc[X.index, "priority"]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )

    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    mse = mean_squared_error(y_test, preds)
    r2  = r2_score(y_test, preds)

    print(f"\n{name.upper()} Model ({type(model).__name__}):")
    print(f"  Samples  : {len(data)}")
    print(f"  Features : {features}")
    print(f"  MSE      : {mse:.3f}")
    print(f"  R2 Score : {r2:.3f}")

    with open(f"{name}_model.pkl", "wb") as fh:
        pickle.dump((model, scaler), fh)

    print(f"  Saved    : {name}_model.pkl")
    plot_results(y_test, preds, name)


# =========================
# TRAIN ALL 6 DISASTERS
# =========================
for disaster, config in FEATURE_MAP.items():
    subset = df[df["disaster_type"] == disaster].copy()
    train_model(
        data=subset,
        features=config["features"],
        model=MODEL_MAP[disaster],
        name=disaster,
    )

print("\n✅ All 6 models trained and saved.")